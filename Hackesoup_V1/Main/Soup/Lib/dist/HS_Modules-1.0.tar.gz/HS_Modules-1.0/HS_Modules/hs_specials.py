import colorama

def placeholder():
    pass